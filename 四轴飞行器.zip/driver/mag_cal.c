#include "mag_cal.h"


_MAG_CAL mag_cal = {0};














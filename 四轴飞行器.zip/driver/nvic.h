#ifndef _nvic_h_
#define _nvic_h_

#include "stm32f10x.h"



void NVIC_config(void);







#endif

